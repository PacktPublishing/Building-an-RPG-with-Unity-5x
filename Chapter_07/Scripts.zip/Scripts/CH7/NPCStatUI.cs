﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class NPCStatUI : MonoBehaviour
{
  public Image imgHealthBar;
  public Image imgManaBar;
}
