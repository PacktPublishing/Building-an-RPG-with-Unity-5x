﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ActiveInventoryItemUI : MonoBehaviour
{
  public InventoryItem item;

  public Image imgActiveItem;
  public Text txtActiveItem;

}
