﻿using UnityEngine;
using UnityEngine.UI;

public class InventoryItemUI : MonoBehaviour {
  public Image  imgItem;
  public Text   txtItemElement;
  public Button butAdd;
  public Button butDelete;

  public InventoryItem item;
}
