﻿using UnityEngine;
using System;
using System.Collections;

[Serializable]
public class NPC : BaseCharacter {

}
